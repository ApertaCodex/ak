#!/bin/bash
# AK Installation Script for macOS

echo "Installing AK..."
cp -r "AK.app" "/Applications/"
echo "✅ AK installed successfully!"
echo "You can now run AK from Applications or use: /Applications/AK.app/Contents/MacOS/ak"
