AK - API Key Manager v4.1.6
================================

Installation Instructions:
1. Run "Install AK.sh" to copy AK.app to Applications
   OR
2. Manually drag AK.app to your Applications folder

Command Line Usage:
After installation, you can use AK from the command line:
/Applications/AK.app/Contents/MacOS/ak --help

Features:
- Secure API key storage
- Cross-platform compatibility
- Command-line interface
- Built with C++17

Build Date: 2025-09-08 04:06:02
Project: https://github.com/ApertaCodex/ak

© 2025 ApertaCodex
